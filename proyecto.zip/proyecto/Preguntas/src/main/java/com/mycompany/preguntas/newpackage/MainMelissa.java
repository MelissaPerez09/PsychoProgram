
package com.mycompany.preguntas.newpackage;

/**
 *
 * @author melissaperez_
 */
public class MainMelissa {
    public static void main (String[] args){
        Preguntas p = new Preguntas();
        
        p.setVisible(true); //se hace visible la ventana
        
    }  
}
