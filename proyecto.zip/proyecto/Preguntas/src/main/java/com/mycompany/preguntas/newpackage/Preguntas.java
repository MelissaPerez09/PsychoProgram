package com.mycompany.preguntas.newpackage;

import java.awt.Color;
import java.awt.Dimension;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

/**
 *
 * @author melissaperez_
 */
public class Preguntas extends JFrame{
    public Preguntas(){
        this.setSize(500,500); //se establece el tamanio de la ventana
        this.setTitle("Preguntas");
        this.setLocationRelativeTo(null); //se posiciona en el centro de la pantalla
        this.getContentPane().setBackground(Color.WHITE); //establecer color de la ventana
        Componentes();
        this.setDefaultCloseOperation(EXIT_ON_CLOSE); //cierra la ventana  
    }
    //todos los componentes de interaccion
    private void Componentes(){
        JPanel panel = new JPanel(); //crea panel
        this.getContentPane().add(panel); //agregar panel
        panel.setLayout(null); //funciona para desactivar el disenio original
        
        JLabel label1 = new JLabel(); //crea la label
        label1.setText("Responde las siguientes preguntas :)"); //establece texto de la label
        label1.setBounds(100, 100, 200, 100);
        panel.add(label1); //se agrega la etiqueta al panel
        
        //PREGUNTA 1
        JLabel label2 = new JLabel();
        label2.setText("(1) Que situaciones tienes en tu vida actualmente?");
        panel.add(label2);
        JTextField texto1 = new JTextField();
        texto1.setBounds(100, 100, 200, 100);
        //texto1.setText("Escribe tu respuesta...");
        panel.add(texto1);
        
        //PREGUNTA 2
        JLabel label3 = new JLabel();
        label3.setText("(2) Como te has sentido con esas situaciones?");
        panel.add(label3);
        JTextField texto2 = new JTextField();
        texto2.setBounds(100, 100, 200, 100);
        //texto1.setText("Escribe tu respuesta...");
        panel.add(texto2);
        
        //PREGUNTA 3
        JLabel label4 = new JLabel();
        label4.setText("(3) Que trae de positivo estas situaciones?");
        panel.add(label4);
        JTextField texto3 = new JTextField();
        texto3.setBounds(100, 100, 200, 100);
        //texto1.setText("Escribe tu respuesta...");
        panel.add(texto3);
        
        //PREGUNTA 4
        JLabel label5 = new JLabel();
        label5.setText("(4) Que trae de negativo estas situaciones?");
        panel.add(label5);
        JTextField texto4 = new JTextField();
        texto4.setBounds(100, 100, 200, 100);
        //texto1.setText("Escribe tu respuesta...");
        panel.add(texto4);
        
        //PREGUNTA 5
        JLabel label6 = new JLabel();
        label6.setText("(5) Que mejorarias o aprovecharias esta situacion?");
        panel.add(label6);
        JTextField texto5 = new JTextField();
        texto5.setBounds(100, 100, 200, 100);
        //texto1.setText("Escribe tu respuesta...");
        panel.add(texto5);
        
        //MENSAJE
        JLabel label7 = new JLabel();
        label7.setText("* Recuerda, siempre hay un aprendizaje en cada paso de la vida :) *");
        panel.add(label7);
    }
}
